import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
public class EnterRealMAndPressBack {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        RealM rm = new RealM();
        try {
            rm.signIN(driver);
            rm.configuration(driver);
            Thread.sleep(3000);
            rm.enterRealMAndPressBack(driver, "RealM1");
        }
        catch (InterruptedException e) {
            System.out.println(e);
        } finally {
//          rm.cleanUp(driver);
            rm.logOut(driver);
        }
    }
}

