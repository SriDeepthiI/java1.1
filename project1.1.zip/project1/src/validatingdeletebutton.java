import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
public class validatingdeletebutton {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        try {
            driver.get("http://20.55.216.158");
            Thread.sleep(3000);
            WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(20));
            w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='inputusername|input']")));
            WebElement Username = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/oj-module[1]/div[1]/div[2]/oj-module[1]/div[1]/div[3]/oj-input-text[1]/div[1]/div[1]/input[1]"));
            WebElement Password = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/oj-module[1]/div[1]/div[2]/oj-module[1]/div[1]/div[3]/oj-input-password[1]/div[1]/div[1]/input[1]"));
//            login into application.
            Username.sendKeys("admin");
            Password.sendKeys("Abcd1234");
            Thread.sleep(10000);
            driver.findElement(By.xpath("//oj-button[@id='loginbtn']//div[@class='oj-button-label']")).click();
            Thread.sleep(5000);
//            Goto configaration and click  codec policy.
            driver.findElement(By.xpath("//span[@class='oj-navigationlist-item-label'][normalize-space()='Configuration']")).click();
            Thread.sleep(5000);
            driver.findElement(By.xpath("//a[contains(text(),'codec-policy')]")).click();
            Thread.sleep(3000);
            driver.findElement(By.xpath("/html[1]/body[1]/div[3]/div[1]/div[1]/div[1]/div[1]/oj-module[1]/div[1]/div[7]/oj-module[1]/div[2]/div[4]/div[1]/div[1]/div[1]/div[2]/oj-module[1]/div[1]/div[3]/div[1]/div[1]/div[3]/div[1]/div[2]/oj-button[1]/button[1]/div[1]/span[1]")).click();
            try {
                WebElement Name = driver.findElement(By.xpath("//input[@id='name|input']"));
                Name.sendKeys("policy1");
                WebElement codecs = driver.findElement(By.xpath("//input[@id='allow-codecs|input']"));
                codecs.sendKeys("AMR");
                codecs.sendKeys(Keys.ENTER);
                codecs.sendKeys("G729");
                codecs.sendKeys(Keys.ENTER);
                driver.findElement(By.xpath("//span[@data-bind='text: label'][normalize-space()='OK']")).click();
                Thread.sleep(3000);
            WebElement Deletebutton = driver.findElement(By.xpath("//span[@id='codec-policy1_deleteAction']"));
            if(Deletebutton.isEnabled()) {
                System.out.println("Codec policy is selected");
            }
            else{
                System.out.println("Codec policy is  not selected successfully");
            }
            Thread.sleep(3000);
             driver.findElement(By.xpath("//oj-selector[@id='codec-policy1_table_selector_d']//input[@type='checkbox']")).click();
            Thread.sleep(3000);

            }
            catch (StaleElementReferenceException e){
                System.out.println(e);

            }
        }
        catch (InterruptedException e) {
            System.out.println(e);
        }
        finally {
            driver.quit();
        }
    }
}
