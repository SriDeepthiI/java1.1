import java.time.Duration;
import java.time.Instant;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
public class RealM {
    String website = "http://20.55.216.158";
    String user = "admin";
    String pwd = "Abcd1234";
    String xpathUser = "/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/oj-module[1]/div[1]/div[2]/oj-module[1]/div[1]/div[3]/oj-input-text[1]/div[1]/div[1]/input[1]";
    String xpathpwd = "/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/oj-module[1]/div[1]/div[2]/oj-module[1]/div[1]/div[3]/oj-input-password[1]/div[1]/div[1]/input[1]";
    String xpathSignin = "//oj-button[@id='loginbtn']//div[@class='oj-button-label']";
    String xpathconfigaration = "//span[@class='oj-navigationlist-item-label'][normalize-space()='Configuration']";
    String xpathRealM = "//a[contains(text(),'realm-config')]";
    String xpathIntialAdd = "//oj-button[@id='add_realm-config_data']//div[@class='oj-button-label']";
    String xpathDeleteAll = "//span[@id='deleteAll_realm-config_buttonText']";
    String xpathconfirmDelete = "//oj-button[@id='dialogConfirmBtn']//div[@class='oj-button-label']";
    String xpathOkButton = "//span[@data-bind='text: label'][normalize-space()='OK']";
    String xpathreferCallTransferRadio = "//oj-select-single[@id='refer-call-transfer']//a[@role='presentation']";
    String xapthEnable = "/html[1]/body[1]/div[1]/div[1]/div[1]/oj-list-view[1]/ul[1]/li[3]/div[1]";
    String xpathAdminMenuDropDown ="//button[@aria-label='admin menu']//span[@class='oj-button-icon oj-end oj-component-icon oj-button-menu-dropdown-icon']";
    String xpathLogOut ="/html[1]/body[1]/div[1]/div[1]/oj-menu[1]/oj-option[3]/a[1]/span[1]";
    String xpathLogoutConfirm ="//oj-button[@id='dialogYesBtn']//span[@class='oj-button-text']";



    public void signIN(WebDriver driver) throws InterruptedException {
        driver.get(website);
        Thread.sleep(3000);
        WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(20));
        w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='inputusername|input']")));
        WebElement userName = driver.findElement(By.xpath(xpathUser));
        WebElement password = driver.findElement(By.xpath(xpathpwd));
        userName.sendKeys(user);
        password.sendKeys(pwd);
        Thread.sleep(10000);
        driver.findElement(By.xpath(xpathSignin)).click();
        Thread.sleep(5000);
    }
    public void configuration(WebDriver driver) throws InterruptedException {
        driver.findElement(By.xpath(xpathconfigaration)).click();
        Thread.sleep(5000);
        driver.findElement(By.xpath(xpathRealM)).click();
        Thread.sleep(5000);
    }
    public boolean addRealM(WebDriver driver, String identifier, int thresholdvalue, int alarmvalue) throws InterruptedException {
        driver.findElement(By.xpath(xpathIntialAdd)).click();
        WebElement name = driver.findElement(By.id("identifier|input"));
        name.sendKeys(identifier);
        Thread.sleep(2000);
        driver.findElement(By.name("mm-in-realm")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath(xpathreferCallTransferRadio)).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath(xapthEnable)).click();
        Thread.sleep(3000);
        driver.findElement(By.name("hide-egress-media-update")).click();
        Thread.sleep(3000);
        driver.findElement(By.name("steering-pool-lower-threshold")).clear();
        Thread.sleep(3000);
        WebElement threshold = driver.findElement(By.name("steering-pool-lower-threshold"));
        String TV = "" + thresholdvalue;
        threshold.sendKeys(TV);
        Thread.sleep(3000);
        driver.findElement(By.name("steering-pool-alarm-monitoring-time")).clear();
        Thread.sleep(3000);
        WebElement alarm = driver.findElement(By.name("steering-pool-alarm-monitoring-time"));
        String AV = "" + alarmvalue;
        alarm.sendKeys(AV);
        Thread.sleep(3000);
        driver.findElement(By.xpath(xpathOkButton)).click();
        WebElement element = driver.findElement(By.xpath("//*[contains(text(), '" + identifier + "')]"));
        if (element != null) {
            return false;
        } else {
            return true;
        }
    }
     public void editRealM(WebDriver driver, String name, String New_Name) throws InterruptedException {
        driver.findElement(By.xpath("//oj-selector[@id='realm-config1_table_selector_" + name + "']//input[@type='checkbox']")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//span[@id='realm-config1_editAction']")).click();
        WebElement nameField = driver.findElement(By.id("identifier|input"));
        nameField.clear();
        nameField.sendKeys(New_Name);
        Thread.sleep(2000);
        driver.findElement(By.xpath(xpathOkButton)).click();
    }
    public boolean deleteAllRealM(WebDriver driver) throws InterruptedException {
        WebElement delete = driver.findElement(By.xpath(xpathDeleteAll));
        if (delete != null) {
            delete.click();
            driver.findElement(By.xpath(xpathconfirmDelete)).click();
            Thread.sleep(3000);
            return true;
        } else {
            return false;
        }
    }
    public void logOut(WebDriver driver) throws InterruptedException {
        driver.findElement(By.xpath(xpathAdminMenuDropDown)).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath(xpathLogOut)).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath(xpathLogoutConfirm)).click();
        Thread.sleep(2000);
        driver.quit();
    }
    public void addMultipleRealM(WebDriver driver, String identifier, int thresholdvalue, int alarmvalue, int n) throws InterruptedException {
        for (int i = 0; i <= n; i++) {
            if (i == 0) {
                driver.findElement(By.xpath(xpathIntialAdd)).click();
            } else {
                driver.findElement(By.id("add_realm-config")).click();
                Thread.sleep(2000);
            }
            WebElement name = driver.findElement(By.id("identifier|input"));
            name.sendKeys(identifier + i);
            driver.findElement(By.name("mm-in-realm")).click();
            driver.findElement(By.xpath(xpathreferCallTransferRadio)).click();
            driver.findElement(By.xpath(xapthEnable)).click();
            driver.findElement(By.name("hide-egress-media-update")).click();
            driver.findElement(By.name("steering-pool-lower-threshold")).clear();
            Thread.sleep(3000);
            WebElement threshold = driver.findElement(By.name("steering-pool-lower-threshold"));
            String TV = "" + thresholdvalue;
            threshold.sendKeys(TV);
            driver.findElement(By.name("steering-pool-alarm-monitoring-time")).clear();
            Thread.sleep(3000);
            WebElement alarm = driver.findElement(By.name("steering-pool-alarm-monitoring-time"));
            String AV = "" + alarmvalue;
            alarm.sendKeys(AV);
            driver.findElement(By.xpath(xpathOkButton)).click();

        }
    }
    public void deleteSelective(WebDriver driver, String nameOfidentifier, int n) throws InterruptedException {
        for (int i = 0; i <= n; i++) {
            String xpathRadio = "//oj-selector[@id='realm-config1_table_selector_" + nameOfidentifier + i + "']//input[@type='checkbox']";
            driver.findElement(By.xpath(xpathRadio)).click();
            driver.findElement(By.id("realm-config1_deleteAction")).click();
            Thread.sleep(2000);
            WebElement confirmDelete = driver.findElement(By.xpath("//oj-button[@id='dialogConfirmBtn']//span[contains(text(),'Confirm')]"));
            confirmDelete.click();
            Thread.sleep(2000);
        }
    }
    public void cleanUp(WebDriver driver) throws InterruptedException {
        try {
            driver.findElement(By.xpath("//a[@title='media-manager']//span[@class='oj-navigationlist-item-label'][normalize-space()='media-manager']")).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath("//span[normalize-space()='realm-config']")).click();
            Thread.sleep(2000);
            boolean delete = deleteAllRealM(driver);
            if (delete) {
                System.out.println("Cleanup Done.");
            } else {
                System.out.println("Error deleting RealM.");
            }
        } catch (InterruptedException e) {
            System.out.println(e);
        }
    }
    public void copyAndSaveWithNewName(WebDriver driver) throws InterruptedException {
        WebElement button = driver.findElement(By.xpath("//oj-selector[@id='realm-config1_table_selector_realm1']//input[@type='checkbox']"));
        button.click();
        Thread.sleep(2000);
        driver.findElement(By.id("realm-config1_copyAction")).click();
        Thread.sleep(3000);
        WebElement name1 = driver.findElement(By.id("identifier|input"));
        name1.clear();
        name1.sendKeys("Realm2");
        Thread.sleep(3000);
        driver.findElement(By.xpath(xpathOkButton)).click();
        Thread.sleep(2000);
    }
    public void enterRealMAndPressBack(WebDriver driver,String nameOfIdentifier) throws InterruptedException {
        driver.findElement(By.xpath(xpathIntialAdd)).click();
        Thread.sleep(2000);
        WebElement name2 = driver.findElement(By.id("identifier|input"));
        name2.sendKeys(nameOfIdentifier);
        driver.findElement(By.xpath("//span[contains(text(),'Back')]")).click();
        Thread.sleep(2000);
        driver.findElement(By.id("dialogYesBtn")).click();
        Thread.sleep(2000);
    }
    public void realMWithEmptyName(WebDriver driver) throws InterruptedException {
        driver.findElement(By.xpath(xpathIntialAdd)).click();
        driver.findElement(By.xpath(xpathOkButton)).click();
        WebElement error = driver.findElement(By.xpath("//span[@id='error_identifier']"));
        Thread.sleep(2000);
        if (error != null) {
            System.out.println("Red Button Displayed");
        } else {
            System.out.println("Red Button Not Displayed");
        }
        Thread.sleep(2000);
    }

    public boolean searchRealM (WebDriver driver,String identifiername) throws InterruptedException {
        WebElement search = driver.findElement(By.id("searchid|input"));
        search.sendKeys(identifiername);
        Thread.sleep(3000);
        driver.findElement(By.id("tableSearchButton")).click();
        Thread.sleep(2000);
        WebElement emptyDataIcons = driver.findElement(By.xpath("//div[@id='realm-config1_emptyDataIcons']"));
        if (emptyDataIcons.isDisplayed()) {
            System.out.println("Identifier '" + identifiername + "' is Not Available");
            return false;
        }
        else{
            System.out.println("Identifier'" + identifiername + "' is Available");
            return true;
        }

    }
}





