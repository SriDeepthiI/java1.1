import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class SearchRealM {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        RealM rm = new RealM();
        try {
            rm.signIN(driver);
            rm.configuration(driver);
            rm.addRealM(driver, "realm1", 80, 30);
            rm.searchRealM(driver, "realm2");
        }
        catch (InterruptedException e) {
            System.out.println(e);
        } finally {
            rm.cleanUp(driver);
            rm.logOut(driver);
        }
    }
}

