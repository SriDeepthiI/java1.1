//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the g
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Widgets {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        try {
            driver.get("http://20.55.216.158");
            Thread.sleep(3000);
            WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(20));
            w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='loginbtn_oj57|text']")));
            WebElement Username = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/oj-module[1]/div[1]/div[2]/oj-module[1]/div[1]/div[3]/oj-input-text[1]/div[1]/div[1]/input[1]"));
            WebElement Password = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/oj-module[1]/div[1]/div[2]/oj-module[1]/div[1]/div[3]/oj-input-password[1]/div[1]/div[1]/input[1]"));
            Username.sendKeys("admin");
            Password.sendKeys("Abcd1234");
            driver.findElement(By.xpath("//span[@id='loginbtn_oj57|text']")).click();
            driver.findElement(By.xpath("//span[@class='oj-navigationlist-item-label'][normalize-space()='Dashboard']")).click();
            Thread.sleep(3000);
            WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("mask")));
            WebElement Widgets = driver.findElement(By.cssSelector("span.oj-button-icon"));
            Widgets.click();
            WebElement dropdownelement = driver.findElement(By.xpath("//span[normalize-space()='Add a Widget']"));
            Select dropdown=new Select(dropdownelement);
            dropdown.selectByVisibleText("Add a Widget");
            Thread.sleep(3000);
//            Widgets.click();
//            WebElement Addwidget = driver.findElement(By.xpath("//span[normalize-space()='Add a Widget']"));
//            Addwidget.click();
//            Thread.sleep(3000);
            WebElement Features = driver.findElement(By.xpath("//button[@aria-label='Add Features widget']//span[contains(text(),'ADD')]"));
            Features.click();
            Thread.sleep(3000);
            driver.findElement(By.xpath("//oj-button[@id='dialogAddBtn']//span[@class='oj-button-text']")).click();
            Thread.sleep(3000);
            driver.findElement(By.xpath("//button[@aria-label='Close add widgets dialog']//span[@class='oj-button-text'][normalize-space()='Close']")).click();
            Thread.sleep(3000);
        }
        catch (InterruptedException e) {
            System.out.println(e);
        }
        finally {
            driver.quit();
        }


//        if(Features!= null){
//            System.out.println("Features widget is added");
//
//        }
//        else{
//            System.out.println("Features widget is not added");
//
//        }
        //driver.quit();






    }
}