import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
public class PolicyWithEmptyName {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        CodecPolicy cp = new CodecPolicy();
        try {
            cp.signIN(driver);
            cp.configuration(driver);
            cp.policyWithEmptyName(driver);
        }
        catch (InterruptedException e) {
            System.out.println(e);
        }
        finally {
            cp.logOut(driver);
        }
    }
}




