import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
public class RealMWithEmptyName {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        RealM rm = new RealM();
        try {
            rm.signIN(driver);
            rm.configuration(driver);
            rm.realMWithEmptyName(driver);
        } catch (InterruptedException e) {
            System.out.println(e);
        } finally {
//          rm.cleanUp(driver);
            rm.logOut(driver);
        }
    }
}



