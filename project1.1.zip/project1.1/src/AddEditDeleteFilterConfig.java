import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
public class AddEditDeleteFilterConfig {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        FilterConfig fc = new FilterConfig();
        try {
            fc.signIn(driver);
            fc.configuration(driver);
            boolean success = fc.addFilterConfig(driver, "filter1", "user1");
            assert success;
            boolean edit = fc.editFilterConfig(driver,"filter1","filter2");
            assert edit;
            boolean delete = fc.deleteFilterConfig(driver,"filter2");
            assert delete;
        } catch (InterruptedException e) {
            System.out.println(e);
        }
        finally {
            fc.cleanUp(driver);
            fc.logout(driver);
        }
    }
}
