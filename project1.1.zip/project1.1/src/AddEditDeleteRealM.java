import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
public class AddEditDeleteRealM {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        RealM rm = new RealM();
        try {
            rm.signIN(driver);
            //Configuration and click RealM Policy.
            rm.configuration(driver);
//            Add Realm Policy
           boolean success = rm.addRealM(driver,"realm1",80,30);
           assert success;
           boolean edit = rm.editRealM(driver,"realm1","realm2");
            assert edit;
           boolean delete = rm.deleteAllRealM(driver);
           assert delete;
            System.out.println("RealM Deleted Successfully");
        } catch (InterruptedException e) {
            System.out.println(e);
        } finally {
//            rm.cleanUp(driver);
            rm.logOut(driver);
        }
    }
}
